"""
test_ollama_connection.py
--------------------------
Standalone connectivity check for a local Ollama server -- run this
BEFORE launching the Streamlit app whenever LLM_PROVIDER=ollama, to
catch connection/model issues early with a clear, actionable message
instead of a confusing error inside the UI.

Usage (from project root, with venv activated):
    python tests/test_ollama_connection.py

Or as a pytest test (skips gracefully if Ollama isn't running):
    python -m pytest tests/test_ollama_connection.py -v
"""

import os
import sys

import requests

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import config
from src.utils.logger import get_logger

logger = get_logger(__name__)

TIMEOUT_SECONDS = 10


def check_server_reachable(base_url: str) -> bool:
    """Step 1: Is the Ollama server even running and reachable?"""
    try:
        resp = requests.get(f"{base_url}/api/tags", timeout=TIMEOUT_SECONDS)
        resp.raise_for_status()
        return True
    except requests.RequestException as exc:
        print(f"❌ Could not reach Ollama server at {base_url}")
        print(f"   Error: {exc}")
        print("   Fix: run `ollama serve` in a separate terminal, then retry.")
        return False


def check_model_available(base_url: str, model: str) -> bool:
    """Step 2: Is the configured model actually pulled locally?"""
    try:
        resp = requests.get(f"{base_url}/api/tags", timeout=TIMEOUT_SECONDS)
        resp.raise_for_status()
        available_models = [m["name"] for m in resp.json().get("models", [])]
    except requests.RequestException as exc:
        print(f"❌ Could not list local models: {exc}")
        return False

    # Ollama tags often include a version suffix (e.g. "llama3.2:latest"),
    # so match on prefix rather than requiring an exact string match.
    match_found = any(m == model or m.startswith(f"{model}:") for m in available_models)

    if not match_found:
        print(f"❌ Model '{model}' not found locally.")
        print(f"   Models currently available: {available_models or '(none)'}")
        print(f"   Fix: run `ollama pull {model}`")
        return False

    print(f"✅ Model '{model}' is available locally.")
    return True


def check_generation_works(base_url: str, model: str) -> bool:
    """Step 3: Does a real generate call succeed and return text?"""
    try:
        resp = requests.post(
            f"{base_url}/api/generate",
            json={
                "model": model,
                "prompt": "Reply with exactly the word: OK",
                "stream": False,
                "options": {"temperature": 0.0},
            },
            timeout=60,
        )
        resp.raise_for_status()
        text = resp.json().get("response", "").strip()
    except requests.RequestException as exc:
        print(f"❌ Test generation call failed: {exc}")
        return False

    if not text:
        print("❌ Ollama responded but returned empty text.")
        return False

    print(f"✅ Test generation succeeded. Sample response: {text[:80]!r}")
    return True


def run_all_checks() -> bool:
    base_url = config.OLLAMA_BASE_URL
    model = config.OLLAMA_MODEL

    print("=" * 60)
    print("Ollama Connection Check")
    print(f"  Base URL : {base_url}")
    print(f"  Model    : {model}")
    print("=" * 60)

    if not check_server_reachable(base_url):
        return False

    print(f"✅ Ollama server is reachable at {base_url}")

    if not check_model_available(base_url, model):
        return False

    if not check_generation_works(base_url, model):
        return False

    print("=" * 60)
    print("🎉 All checks passed. Ollama is ready -- you can now run:")
    print("     streamlit run src/app.py")
    print("=" * 60)
    return True


# ---------------------------------------------------------------------
# Pytest-compatible test (skips instead of failing the whole suite if
# Ollama isn't running -- useful when running `pytest tests/` broadly
# on a machine that only has OpenAI configured).
# ---------------------------------------------------------------------
def test_ollama_is_reachable_and_model_available():
    import pytest

    if config.LLM_PROVIDER != "ollama":
        pytest.skip("LLM_PROVIDER is not set to 'ollama' in .env -- skipping Ollama checks.")

    base_url = config.OLLAMA_BASE_URL
    if not check_server_reachable(base_url):
        pytest.skip(f"Ollama server not reachable at {base_url} -- start it with `ollama serve`.")

    assert check_model_available(base_url, config.OLLAMA_MODEL), (
        f"Model '{config.OLLAMA_MODEL}' not pulled. Run: ollama pull {config.OLLAMA_MODEL}"
    )
    assert check_generation_works(base_url, config.OLLAMA_MODEL), "Ollama generation call failed."


if __name__ == "__main__":
    success = run_all_checks()
    sys.exit(0 if success else 1)

"""
test_smoke.py
-------------
Lightweight end-to-end sanity checks that don't require the LLM API
or downloading ML models. Run with:

    python -m pytest tests/test_smoke.py -v
"""

import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.ingestion.loaders import load_all_documents, RawDocument
from src.ingestion.chunking import chunk_documents, chunk_document
from src.retrieval.bm25_search import BM25Search


def test_load_all_documents_reads_sample_data():
    documents = load_all_documents("data")
    assert len(documents) > 0, "Expected at least one sample document in data/"
    for doc in documents:
        assert isinstance(doc, RawDocument)
        assert doc.text.strip() != ""


def test_chunking_produces_bounded_chunks():
    documents = load_all_documents("data")
    chunks = chunk_documents(documents, chunk_size=300, chunk_overlap=50)
    assert len(chunks) >= len(documents)
    for chunk in chunks:
        assert len(chunk.text) <= 300 + 50 + 20


def test_chunk_document_single_short_text():
    doc = RawDocument(source="test.txt", text="Short sentence. Another sentence.")
    chunks = chunk_document(doc, chunk_size=500, chunk_overlap=50)
    assert len(chunks) == 1
    assert chunks[0].source == "test.txt"


def test_bm25_search_returns_relevant_chunk_first():
    documents = load_all_documents("data")
    chunks = chunk_documents(documents, chunk_size=400, chunk_overlap=50)
    bm25 = BM25Search(chunks)

    results = bm25.search("leave carry forward", top_k=3)
    assert len(results) > 0
    top_chunk, top_score = results[0]
    assert top_score >= 0


if __name__ == "__main__":
    test_load_all_documents_reads_sample_data()
    test_chunking_produces_bounded_chunks()
    test_chunk_document_single_short_text()
    test_bm25_search_returns_relevant_chunk_first()
    print("All smoke tests passed!")

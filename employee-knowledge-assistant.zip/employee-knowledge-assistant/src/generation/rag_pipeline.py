"""
rag_pipeline.py
---------------
Orchestrates the full RAG flow for a single user query:

    query -> embed -> hybrid search -> rerank -> build prompt
          -> call LLM -> parse sources -> update memory -> return
"""

from dataclasses import dataclass, field
from typing import List, Tuple

from src import config
from src.retrieval.embedder import get_embedder
from src.retrieval.vector_store import VectorStore
from src.retrieval.bm25_search import BM25Search
from src.retrieval.hybrid_search import hybrid_search
from src.retrieval.reranker import get_reranker
from src.generation.llm_client import get_llm_client
from src.generation.memory import ConversationMemory
from src.generation.prompts import SYSTEM_PROMPT, build_user_prompt
from src.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class RAGResponse:
    answer: str
    sources: List[str] = field(default_factory=list)
    used_context: bool = True


class RAGPipeline:
    def __init__(self, vector_store: VectorStore, bm25_search: BM25Search):
        self.embedder = get_embedder()
        self.vector_store = vector_store
        self.bm25_search = bm25_search
        self.reranker = get_reranker()
        self.llm = get_llm_client()
        self.memory = ConversationMemory()

    def answer(self, question: str) -> RAGResponse:
        logger.info(f"User question: {question}")

        query_embedding = self.embedder.embed([question])[0]

        candidates: List[Tuple] = hybrid_search(
            query=question,
            query_embedding=query_embedding,
            vector_store=self.vector_store,
            bm25_search=self.bm25_search,
        )

        if not candidates:
            answer = "I could not find this information in the available policy documents."
            self.memory.add_turn(question, answer)
            return RAGResponse(answer=answer, sources=[], used_context=False)

        reranked = self.reranker.rerank(question, candidates, top_k=config.TOP_K_FINAL_CONTEXT)

        context_chunks = [(chunk.text, chunk.source) for chunk, _ in reranked]
        history_text = self.memory.get_history_text()
        user_prompt = build_user_prompt(question, context_chunks, history_text)

        answer = self.llm.generate(SYSTEM_PROMPT, user_prompt)

        sources = sorted({source for _, source in context_chunks})

        self.memory.add_turn(question, answer)

        logger.info(f"Answer generated, grounded in {len(sources)} source(s)")
        return RAGResponse(answer=answer, sources=sources, used_context=True)

    def reset_memory(self) -> None:
        self.memory.clear()

"""
llm_client.py
-------------
Thin abstraction over the LLM call so the rest of the app does not
care whether we're using a paid API (OpenAI) or a free local model
served by Ollama.
"""

import requests

from src import config
from src.utils.logger import get_logger

logger = get_logger(__name__)


class OpenAILLM:
    def __init__(self, model: str = config.LLM_MODEL):
        from openai import OpenAI
        self.client = OpenAI(api_key=config.OPENAI_API_KEY)
        self.model = model

    def generate(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            temperature=temperature,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        return response.choices[0].message.content.strip()


class OllamaLLM:
    """Free, fully local alternative -- requires Ollama running
    (https://ollama.com) with a model already pulled, e.g. `ollama pull llama3.2`."""

    def __init__(self, model: str = config.OLLAMA_MODEL, base_url: str = config.OLLAMA_BASE_URL):
        self.model = model
        self.base_url = base_url.rstrip("/")

    def generate(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        combined_prompt = f"{system_prompt}\n\n{user_prompt}"
        try:
            resp = requests.post(
                f"{self.base_url}/api/generate",
                json={"model": self.model, "prompt": combined_prompt, "stream": False,
                      "options": {"temperature": temperature}},
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json().get("response", "").strip()
        except requests.RequestException as exc:
            logger.error(f"Ollama request failed: {exc}")
            return "Sorry, the local LLM (Ollama) is not reachable right now."


def get_llm_client():
    if config.LLM_PROVIDER == "ollama":
        logger.info("Using Ollama (local, free) LLM")
        return OllamaLLM()
    logger.info("Using OpenAI LLM")
    return OpenAILLM()

"""
memory.py
---------
Conversational memory so follow-up questions like "What about
carry-forward?" are correctly resolved against the previous turn.
"""

from collections import deque
from typing import Deque, List, Tuple

from src import config


class ConversationMemory:
    def __init__(self, max_turns: int = config.MEMORY_MAX_TURNS):
        self.max_turns = max_turns
        self._turns: Deque[Tuple[str, str]] = deque(maxlen=max_turns)

    def add_turn(self, question: str, answer: str) -> None:
        self._turns.append((question, answer))

    def get_history_text(self) -> str:
        if not self._turns:
            return ""
        lines = []
        for q, a in self._turns:
            lines.append(f"User: {q}")
            lines.append(f"Assistant: {a}")
        return "\n".join(lines)

    def get_turns(self) -> List[Tuple[str, str]]:
        return list(self._turns)

    def clear(self) -> None:
        self._turns.clear()

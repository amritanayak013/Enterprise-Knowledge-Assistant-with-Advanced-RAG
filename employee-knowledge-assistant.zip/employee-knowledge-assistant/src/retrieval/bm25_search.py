"""
bm25_search.py
--------------
Keyword-based retrieval using the BM25 ranking algorithm.
"""

import re
from typing import List, Tuple

from rank_bm25 import BM25Okapi

from src.ingestion.chunking import Chunk
from src.utils.logger import get_logger

logger = get_logger(__name__)

_TOKEN_PATTERN = re.compile(r"[a-z0-9]+")


def _tokenize(text: str) -> List[str]:
    return _TOKEN_PATTERN.findall(text.lower())


class BM25Search:
    def __init__(self, chunks: List[Chunk]):
        self.chunks = chunks
        tokenized_corpus = [_tokenize(chunk.text) for chunk in chunks]
        self.bm25 = BM25Okapi(tokenized_corpus)
        logger.info(f"BM25 index built over {len(chunks)} chunk(s)")

    def search(self, query: str, top_k: int = 8) -> List[Tuple[Chunk, float]]:
        tokenized_query = _tokenize(query)
        scores = self.bm25.get_scores(tokenized_query)

        scored = list(zip(self.chunks, scores))
        scored.sort(key=lambda pair: pair[1], reverse=True)
        return scored[:top_k]

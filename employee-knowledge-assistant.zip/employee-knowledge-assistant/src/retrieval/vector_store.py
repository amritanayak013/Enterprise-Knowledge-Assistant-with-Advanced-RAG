"""
vector_store.py
----------------
Local vector storage & semantic (vector) search using FAISS.
"""

import os
import pickle
from typing import List, Tuple

import faiss
import numpy as np

from src.ingestion.chunking import Chunk
from src.utils.logger import get_logger

logger = get_logger(__name__)


class VectorStore:
    def __init__(self, dim: int):
        self.dim = dim
        self.index = faiss.IndexFlatIP(dim)
        self.chunks: List[Chunk] = []

    def add(self, embeddings: np.ndarray, chunks: List[Chunk]) -> None:
        assert embeddings.shape[0] == len(chunks), "Embeddings/chunks length mismatch"
        faiss.normalize_L2(embeddings)
        self.index.add(embeddings)
        self.chunks.extend(chunks)

    def search(self, query_embedding: np.ndarray, top_k: int = 8) -> List[Tuple[Chunk, float]]:
        if self.index.ntotal == 0:
            return []
        query_embedding = query_embedding.reshape(1, -1).astype("float32")
        faiss.normalize_L2(query_embedding)
        scores, indices = self.index.search(query_embedding, min(top_k, self.index.ntotal))

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append((self.chunks[idx], float(score)))
        return results

    def save(self, index_path: str, metadata_path: str) -> None:
        os.makedirs(os.path.dirname(index_path), exist_ok=True)
        faiss.write_index(self.index, index_path)
        with open(metadata_path, "wb") as f:
            pickle.dump(self.chunks, f)
        logger.info(f"Vector store saved: {index_path} ({self.index.ntotal} vectors)")

    @classmethod
    def load(cls, index_path: str, metadata_path: str) -> "VectorStore":
        index = faiss.read_index(index_path)
        with open(metadata_path, "rb") as f:
            chunks = pickle.load(f)
        store = cls(dim=index.d)
        store.index = index
        store.chunks = chunks
        logger.info(f"Vector store loaded: {index_path} ({index.ntotal} vectors)")
        return store

"""
hybrid_search.py
----------------
Combines vector (semantic) search and BM25 (keyword) search into a
single ranked list using min-max normalized weighted score fusion.
"""

from typing import List, Tuple, Dict

from src.ingestion.chunking import Chunk
from src.retrieval.vector_store import VectorStore
from src.retrieval.bm25_search import BM25Search
from src.utils.logger import get_logger
from src import config

logger = get_logger(__name__)


def _min_max_normalize(scores: Dict[str, float]) -> Dict[str, float]:
    if not scores:
        return {}
    values = list(scores.values())
    lo, hi = min(values), max(values)
    if hi - lo < 1e-9:
        return {k: 0.0 for k in scores}
    return {k: (v - lo) / (hi - lo) for k, v in scores.items()}


def hybrid_search(
    query: str,
    query_embedding,
    vector_store: VectorStore,
    bm25_search: BM25Search,
    top_k_vector: int = config.TOP_K_VECTOR,
    top_k_bm25: int = config.TOP_K_BM25,
    top_k_hybrid: int = config.TOP_K_HYBRID,
    alpha: float = config.HYBRID_ALPHA,
) -> List[Tuple[Chunk, float]]:
    vector_results = vector_store.search(query_embedding, top_k=top_k_vector)
    bm25_results = bm25_search.search(query, top_k=top_k_bm25)

    vector_scores = {chunk.chunk_id: score for chunk, score in vector_results}
    bm25_scores = {chunk.chunk_id: score for chunk, score in bm25_results}

    norm_vector = _min_max_normalize(vector_scores)
    norm_bm25 = _min_max_normalize(bm25_scores)

    chunk_lookup = {chunk.chunk_id: chunk for chunk, _ in vector_results}
    chunk_lookup.update({chunk.chunk_id: chunk for chunk, _ in bm25_results})

    fused_scores: Dict[str, float] = {}
    for chunk_id in chunk_lookup:
        v = norm_vector.get(chunk_id, 0.0)
        b = norm_bm25.get(chunk_id, 0.0)
        fused_scores[chunk_id] = alpha * v + (1 - alpha) * b

    ranked_ids = sorted(fused_scores, key=fused_scores.get, reverse=True)[:top_k_hybrid]
    results = [(chunk_lookup[cid], fused_scores[cid]) for cid in ranked_ids]

    logger.info(f"Hybrid search: query='{query[:50]}...' -> {len(results)} candidate(s)")
    return results

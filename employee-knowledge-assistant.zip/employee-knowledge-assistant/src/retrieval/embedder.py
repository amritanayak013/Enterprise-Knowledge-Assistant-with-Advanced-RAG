"""
embedder.py
-----------
Turns text chunks into vector embeddings. Two interchangeable
providers: free/local (sentence-transformers) or paid (OpenAI),
selected via .env (EMBEDDING_PROVIDER).
"""

from typing import List
import numpy as np

from src import config
from src.utils.logger import get_logger

logger = get_logger(__name__)


class LocalEmbedder:
    """Free, local embeddings using sentence-transformers."""

    def __init__(self, model_name: str = config.EMBEDDING_MODEL_LOCAL):
        from sentence_transformers import SentenceTransformer
        logger.info(f"Loading local embedding model: {model_name}")
        self.model = SentenceTransformer(model_name)

    def embed(self, texts: List[str]) -> np.ndarray:
        embeddings = self.model.encode(texts, show_progress_bar=False, normalize_embeddings=True)
        return np.asarray(embeddings, dtype="float32")


class OpenAIEmbedder:
    """Paid embeddings via the OpenAI API. Requires OPENAI_API_KEY."""

    def __init__(self, model_name: str = config.EMBEDDING_MODEL_OPENAI):
        from openai import OpenAI
        self.client = OpenAI(api_key=config.OPENAI_API_KEY)
        self.model_name = model_name

    def embed(self, texts: List[str]) -> np.ndarray:
        response = self.client.embeddings.create(model=self.model_name, input=texts)
        vectors = [item.embedding for item in response.data]
        arr = np.asarray(vectors, dtype="float32")
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms[norms == 0] = 1e-9
        return arr / norms


def get_embedder():
    if config.EMBEDDING_PROVIDER == "openai":
        logger.info("Using OpenAI embeddings")
        return OpenAIEmbedder()
    logger.info("Using local sentence-transformers embeddings")
    return LocalEmbedder()

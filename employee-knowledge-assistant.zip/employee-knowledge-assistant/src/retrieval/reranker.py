"""
reranker.py
-----------
Reranking step applied AFTER hybrid retrieval, to reorder the small
candidate set by true query-document relevance before it is sent to
the LLM as context.
"""

from typing import List, Tuple

from src.ingestion.chunking import Chunk
from src import config
from src.utils.logger import get_logger

logger = get_logger(__name__)


class CrossEncoderReranker:
    def __init__(self, model_name: str = config.RERANKER_MODEL):
        from sentence_transformers import CrossEncoder
        logger.info(f"Loading cross-encoder reranker: {model_name}")
        self.model = CrossEncoder(model_name)

    def rerank(self, query: str, candidates: List[Tuple[Chunk, float]], top_k: int) -> List[Tuple[Chunk, float]]:
        pairs = [(query, chunk.text) for chunk, _ in candidates]
        scores = self.model.predict(pairs)
        reranked = sorted(zip([c for c, _ in candidates], scores), key=lambda p: p[1], reverse=True)
        return [(chunk, float(score)) for chunk, score in reranked[:top_k]]


class SimpleTfidfReranker:
    """No heavyweight model download required -- good for quick local
    smoke-testing before installing sentence-transformers."""

    def rerank(self, query: str, candidates: List[Tuple[Chunk, float]], top_k: int) -> List[Tuple[Chunk, float]]:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity

        texts = [chunk.text for chunk, _ in candidates]
        if not texts:
            return []

        vectorizer = TfidfVectorizer(stop_words="english")
        matrix = vectorizer.fit_transform(texts + [query])
        query_vec = matrix[-1]
        doc_vecs = matrix[:-1]
        sims = cosine_similarity(query_vec, doc_vecs).flatten()

        reranked = sorted(zip([c for c, _ in candidates], sims), key=lambda p: p[1], reverse=True)
        return [(chunk, float(score)) for chunk, score in reranked[:top_k]]


def get_reranker():
    if config.RERANKER_MODE == "simple":
        logger.info("Using SimpleTfidfReranker (no model download required)")
        return SimpleTfidfReranker()
    logger.info("Using CrossEncoderReranker")
    return CrossEncoderReranker()

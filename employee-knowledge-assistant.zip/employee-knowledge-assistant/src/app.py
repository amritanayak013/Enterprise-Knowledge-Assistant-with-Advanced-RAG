"""
app.py
------
Streamlit chat interface.
Run with:
    streamlit run src/app.py
"""

import os
import sys

import streamlit as st

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import config
from src.retrieval.vector_store import VectorStore
from src.retrieval.bm25_search import BM25Search
from src.generation.rag_pipeline import RAGPipeline
from src.utils.logger import get_logger

logger = get_logger(__name__)

st.set_page_config(page_title="Employee Knowledge Assistant", page_icon="💼", layout="centered")


@st.cache_resource(show_spinner="Loading knowledge base and models... (first run may take a minute)")
def load_pipeline() -> RAGPipeline:
    if not os.path.exists(config.VECTOR_DB_PATH):
        st.error(
            "No vector index found. Please run `python -m src.ingestion.build_index` "
            "first to ingest the documents in the data/ folder."
        )
        st.stop()

    vector_store = VectorStore.load(config.VECTOR_DB_PATH, config.VECTOR_DB_METADATA_PATH)
    bm25 = BM25Search(vector_store.chunks)
    return RAGPipeline(vector_store=vector_store, bm25_search=bm25)


def main():
    st.title("💼 Employee Knowledge Assistant")
    st.caption("Ask questions about Leave, HR, IT, Travel, Benefits, and company policies.")

    pipeline = load_pipeline()

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    with st.sidebar:
        st.header("Controls")
        if st.button("🗑️ Clear / Reset Conversation"):
            st.session_state.chat_history = []
            pipeline.reset_memory()
            st.rerun()
        st.markdown("---")
        st.markdown("**Retrieval mode:** Hybrid (Vector + BM25) + Reranking")
        st.markdown(f"**LLM provider:** `{config.LLM_PROVIDER}`")

    for turn in st.session_state.chat_history:
        with st.chat_message(turn["role"]):
            st.markdown(turn["content"])
            if turn.get("sources"):
                with st.expander("📄 Sources"):
                    for src in turn["sources"]:
                        st.markdown(f"- {src}")

    user_question = st.chat_input("Ask a question about company policies...")
    if user_question:
        st.session_state.chat_history.append({"role": "user", "content": user_question})
        with st.chat_message("user"):
            st.markdown(user_question)

        with st.chat_message("assistant"):
            with st.spinner("Searching policy documents..."):
                try:
                    response = pipeline.answer(user_question)
                except Exception as exc:
                    logger.error(f"Pipeline error: {exc}")
                    response = None
                    st.error(
                        "Something went wrong while generating the answer. "
                        "Please check the logs (logs/app.log) or try again."
                    )

            if response is not None:
                st.markdown(response.answer)
                if response.sources:
                    with st.expander("📄 Sources"):
                        for src in response.sources:
                            st.markdown(f"- {src}")

                st.session_state.chat_history.append({
                    "role": "assistant",
                    "content": response.answer,
                    "sources": response.sources,
                })


if __name__ == "__main__":
    main()

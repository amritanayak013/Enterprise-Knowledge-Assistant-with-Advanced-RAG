"""
config.py
---------
Central place that loads environment variables (from .env) and exposes
them as typed Python constants so the rest of the codebase never calls
os.environ directly. This makes it trivial to see every configurable
knob of the application in one file.
"""

import os
from dotenv import load_dotenv

load_dotenv()


def _get_int(name: str, default: int) -> int:
    val = os.getenv(name)
    return int(val) if val else default


def _get_float(name: str, default: float) -> float:
    val = os.getenv(name)
    return float(val) if val else default


# ---------------- LLM ----------------
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "openai")          # "openai" | "ollama"
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")

# ---------------- Embeddings ----------------
EMBEDDING_PROVIDER = os.getenv("EMBEDDING_PROVIDER", "local")  # "local" | "openai"
EMBEDDING_MODEL_LOCAL = os.getenv("EMBEDDING_MODEL_LOCAL", "all-MiniLM-L6-v2")
EMBEDDING_MODEL_OPENAI = os.getenv("EMBEDDING_MODEL_OPENAI", "text-embedding-3-small")

# ---------------- Reranker ----------------
RERANKER_MODE = os.getenv("RERANKER_MODE", "cross_encoder")  # "cross_encoder" | "simple"
RERANKER_MODEL = os.getenv("RERANKER_MODEL", "cross-encoder/ms-marco-MiniLM-L-6-v2")

# ---------------- Paths ----------------
DATA_DIR = os.getenv("DATA_DIR", "data")
VECTOR_DB_PATH = os.getenv("VECTOR_DB_PATH", "vector_db/faiss_index")
VECTOR_DB_METADATA_PATH = os.getenv("VECTOR_DB_METADATA_PATH", "vector_db/metadata.pkl")

# ---------------- Chunking ----------------
CHUNK_SIZE = _get_int("CHUNK_SIZE", 500)
CHUNK_OVERLAP = _get_int("CHUNK_OVERLAP", 75)

# ---------------- Retrieval ----------------
TOP_K_VECTOR = _get_int("TOP_K_VECTOR", 8)
TOP_K_BM25 = _get_int("TOP_K_BM25", 8)
TOP_K_HYBRID = _get_int("TOP_K_HYBRID", 6)
TOP_K_FINAL_CONTEXT = _get_int("TOP_K_FINAL_CONTEXT", 4)
HYBRID_ALPHA = _get_float("HYBRID_ALPHA", 0.5)  # weight given to vector score vs BM25 score

# ---------------- Memory ----------------
MEMORY_MAX_TURNS = _get_int("MEMORY_MAX_TURNS", 6)

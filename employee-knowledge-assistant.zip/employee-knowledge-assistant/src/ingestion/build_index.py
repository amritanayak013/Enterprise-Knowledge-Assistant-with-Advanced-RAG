"""
build_index.py
---------------
Standalone script that runs the full ingestion pipeline once:
    Load documents -> Chunk -> Embed -> Save FAISS index + metadata

Run this whenever data/ changes:
    python -m src.ingestion.build_index
"""

import numpy as np

from src import config
from src.ingestion.loaders import load_all_documents
from src.ingestion.chunking import chunk_documents
from src.retrieval.embedder import get_embedder
from src.retrieval.vector_store import VectorStore
from src.utils.logger import get_logger

logger = get_logger(__name__)


def main():
    logger.info("=== Starting ingestion pipeline ===")

    documents = load_all_documents(config.DATA_DIR)
    if not documents:
        logger.error("No documents were loaded. Aborting index build.")
        return

    chunks = chunk_documents(documents, chunk_size=config.CHUNK_SIZE, chunk_overlap=config.CHUNK_OVERLAP)
    if not chunks:
        logger.error("No chunks were produced. Aborting index build.")
        return

    embedder = get_embedder()
    texts = [chunk.text for chunk in chunks]
    embeddings = embedder.embed(texts)
    embeddings = np.asarray(embeddings, dtype="float32")

    store = VectorStore(dim=embeddings.shape[1])
    store.add(embeddings, chunks)
    store.save(config.VECTOR_DB_PATH, config.VECTOR_DB_METADATA_PATH)

    logger.info("=== Ingestion pipeline complete ===")
    logger.info(f"Documents processed : {len(documents)}")
    logger.info(f"Chunks created      : {len(chunks)}")
    logger.info(f"Vector store path   : {config.VECTOR_DB_PATH}")


if __name__ == "__main__":
    main()

"""
chunking.py
-----------
Phase 2 - Splits long documents into overlapping chunks suitable for
embedding and retrieval, using a recursive character-splitting strategy
(paragraph -> sentence -> word -> character) similar in spirit to
LangChain's RecursiveCharacterTextSplitter.
"""

from dataclasses import dataclass, field
from typing import List

from src.ingestion.loaders import RawDocument
from src.utils.logger import get_logger

logger = get_logger(__name__)

_SEPARATORS = ["\n\n", "\n", ". ", " ", ""]


@dataclass
class Chunk:
    chunk_id: str
    text: str
    source: str
    chunk_index: int
    metadata: dict = field(default_factory=dict)


def _split_text(text: str, chunk_size: int, separators: List[str]) -> List[str]:
    if len(text) <= chunk_size or not separators:
        return [text]

    sep = separators[0]
    remaining_separators = separators[1:]

    if sep == "":
        return [text[i:i + chunk_size] for i in range(0, len(text), chunk_size)]

    parts = text.split(sep)
    chunks: List[str] = []
    current = ""

    for part in parts:
        candidate = (current + sep + part) if current else part
        if len(candidate) <= chunk_size:
            current = candidate
        else:
            if current:
                chunks.append(current)
            if len(part) > chunk_size:
                chunks.extend(_split_text(part, chunk_size, remaining_separators))
                current = ""
            else:
                current = part

    if current:
        chunks.append(current)

    return chunks


def _add_overlap(chunks: List[str], overlap: int) -> List[str]:
    if overlap <= 0 or len(chunks) <= 1:
        return chunks

    overlapped = [chunks[0]]
    for i in range(1, len(chunks)):
        prev_tail = chunks[i - 1][-overlap:]
        overlapped.append(prev_tail + chunks[i])
    return overlapped


def chunk_document(document: RawDocument, chunk_size: int = 500, chunk_overlap: int = 75) -> List[Chunk]:
    raw_chunks = _split_text(document.text, chunk_size, _SEPARATORS)
    raw_chunks = _add_overlap(raw_chunks, chunk_overlap)

    chunks = [
        Chunk(
            chunk_id=f"{document.source}::chunk_{i}",
            text=chunk_text.strip(),
            source=document.source,
            chunk_index=i,
            metadata={"source": document.source, "chunk_index": i},
        )
        for i, chunk_text in enumerate(raw_chunks)
        if chunk_text.strip()
    ]
    return chunks


def chunk_documents(documents: List[RawDocument], chunk_size: int = 500, chunk_overlap: int = 75) -> List[Chunk]:
    all_chunks: List[Chunk] = []
    for doc in documents:
        doc_chunks = chunk_document(doc, chunk_size, chunk_overlap)
        all_chunks.extend(doc_chunks)
        logger.info(f"{doc.source}: split into {len(doc_chunks)} chunk(s)")

    logger.info(f"Total chunks created: {len(all_chunks)}")
    return all_chunks

"""
loaders.py
----------
Phase 2 - Document Ingestion.
Reads .txt, .pdf, .docx files from the data/ folder and converts each
into plain text, tagged with its source filename for citations.
"""

import os
from dataclasses import dataclass
from typing import List

import pdfplumber
from docx import Document as DocxDocument

from src.utils.logger import get_logger

logger = get_logger(__name__)

SUPPORTED_EXTENSIONS = {".txt", ".pdf", ".docx"}


@dataclass
class RawDocument:
    source: str
    text: str


def _load_txt(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def _load_pdf(path: str) -> str:
    text_parts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_parts.append(page_text)
    return "\n".join(text_parts)


def _load_docx(path: str) -> str:
    doc = DocxDocument(path)
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())


def load_document(path: str) -> RawDocument:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".txt":
        text = _load_txt(path)
    elif ext == ".pdf":
        text = _load_pdf(path)
    elif ext == ".docx":
        text = _load_docx(path)
    else:
        raise ValueError(f"Unsupported file extension: {ext}")

    return RawDocument(source=os.path.basename(path), text=text)


def load_all_documents(data_dir: str) -> List[RawDocument]:
    documents: List[RawDocument] = []

    if not os.path.isdir(data_dir):
        logger.error(f"Data directory not found: {data_dir}")
        return documents

    filenames = sorted(os.listdir(data_dir))
    logger.info(f"Found {len(filenames)} file(s) in {data_dir}")

    for filename in filenames:
        path = os.path.join(data_dir, filename)
        ext = os.path.splitext(filename)[1].lower()

        if not os.path.isfile(path):
            continue
        if ext not in SUPPORTED_EXTENSIONS:
            logger.warning(f"Skipping unsupported file: {filename}")
            continue

        try:
            doc = load_document(path)
            if not doc.text.strip():
                logger.warning(f"Skipping empty document: {filename}")
                continue
            documents.append(doc)
            logger.info(f"Loaded {filename} ({len(doc.text)} characters)")
        except Exception as exc:
            logger.error(f"Failed to load {filename}: {exc}")
            continue

    logger.info(f"Successfully loaded {len(documents)} document(s)")
    return documents
